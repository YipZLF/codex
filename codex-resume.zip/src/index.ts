#!/usr/bin/env node
import { Command } from 'commander';
import chalk from 'chalk';
import path from 'node:path';
import fs from 'node:fs/promises';
import { loadConfig } from './config.js';
import { resolveLogDirs } from './paths.js';
import { indexSessions } from './indexer.js';
import { shortId } from './utils.js';
import { makeResumePlan, executePlan } from './resume.js';
import OpenAI from 'openai';

const program = new Command();
program
  .name('codex-sessions')
  .description('Resume / rollback / branch manager for Codex CLI sessions');

program.command('list')
  .option('--json', 'output JSON')
  .action(async (opts) => {
    const cfg = await loadConfig();
    const dirs = resolveLogDirs(cfg.logDirs);
    const sessions = await indexSessions(dirs);
    if (opts.json) {
      console.log(JSON.stringify(sessions, null, 2));
      return;
    }
    for (const s of sessions) {
      console.log(`${chalk.cyan(s.sessionId)}  ${chalk.gray(s.path)}`);
      const turns = s.turns.filter(t=>t.response_id);
      const first = turns[0]?.response_id;
      const tip = turns[turns.length - 1]?.response_id;
      console.log(`  turns: ${s.turns.length}, model: ${s.model ?? '∅'}, first: ${shortId(first)}, tip: ${shortId(tip)}`);
    }
  });

program.command('show')
  .argument('<sessionId>', 'session id (directory name)')
  .action(async (sessionId) => {
    const cfg = await loadConfig();
    const dirs = resolveLogDirs(cfg.logDirs);
    const sessions = await indexSessions(dirs);
    const s = sessions.find(x => x.sessionId === sessionId);
    if (!s) {
      console.error(chalk.red(`Session not found: ${sessionId}`));
      process.exit(1);
    }
    console.log(`${chalk.bold('Session:')} ${chalk.cyan(s.sessionId)}  ${chalk.gray(s.path)}`);
    for (const t of s.turns) {
      const rid = t.response_id ? shortId(t.response_id) : '∅';
      const prev = t.previous_response_id ? shortId(t.previous_response_id) : '∅';
      const ts = new Date(t.created_at ?? Date.now()).toISOString();
      console.log(`  [${t.idx}] prev=${prev} → resp=${chalk.green(rid)}  ${chalk.gray(ts)}  ${t.summary ?? ''}`);
    }
    console.log(chalk.gray('Edges:'));
    for (const e of s.dagEdges) {
      console.log(`  ${shortId(e.from)} -> ${shortId(e.to)}`);
    }
  });

program.command('resume')
  .argument('<sessionId>')
  .option('--at <responseId>', 'resume from a specific response id')
  .option('--step <n>', 'resume from the n-th turn (0-based)', (v)=>parseInt(v,10))
  .option('--first', 'resume from the first turn')
  .option('--prompt <text>', 'next user message text')
  .option('--prompt-file <path>', 'read prompt from a file')
  .option('--mode <mode>', 'auto|server|replay')
  .option('--model <model>', 'model override')
  .option('--instructions-file <path>', 'instructions markdown file')
  .option('--store', 'set store: true', true)
  .option('--no-store', 'set store: false')
  .option('--dry-run', 'print plan but do not call API')
  .action(async (sessionId, opts) => {
    const cfg = await loadConfig();
    const dirs = resolveLogDirs(cfg.logDirs);
    const sessions = await indexSessions(dirs);
    const s = sessions.find(x => x.sessionId === sessionId);
    if (!s) {
      console.error(chalk.red(`Session not found: ${sessionId}`));
      process.exit(1);
    }
    const atStep = opts.first ? 0 : (typeof opts.step === 'number' ? opts.step : null);
    let prompt = opts.prompt ?? null;
    if (!prompt && opts['promptFile']) {
      prompt = await fs.readFile(opts['promptFile'], 'utf8');
    }
    if (!prompt) {
      console.error(chalk.red('Missing --prompt or --prompt-file'));
      process.exit(1);
    }
    const plan = await makeResumePlan(s, opts.at ?? null, atStep, {
      model: opts.model ?? cfg.model,
      instructionsFile: opts.instructionsFile ?? cfg.instructionsFile,
      store: typeof opts.store === 'boolean' ? opts.store : cfg.store,
      mode: (opts.mode ?? cfg.mode) as any,
      prompt,
    });
    console.log(chalk.gray('Resume plan: '), JSON.stringify({ ...plan, inputPreview: plan.input.slice(-2) }, null, 2));
    if (opts.dryRun) return;
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      console.error(chalk.red('OPENAI_API_KEY is not set.'));
      process.exit(1);
    }
    const client = new OpenAI({ apiKey });
    const out = await executePlan(plan, client);
    console.log('\n' + chalk.bold('Assistant:') + '\n');
    console.log(out.trim());
  });

program.command('branch')
  .argument('<sessionId>')
  .requiredOption('--from <responseId>', 'base response id')
  .requiredOption('--name <branchName>', 'branch name')
  .action(async (sessionId, opts) => {
    const cfg = await loadConfig();
    const dirs = resolveLogDirs(cfg.logDirs);
    const sessions = await indexSessions(dirs);
    const s = sessions.find(x => x.sessionId === sessionId);
    if (!s) {
      console.error(chalk.red(`Session not found: ${sessionId}`));
      process.exit(1);
    }
    // Keep a light-weight pointer file
    const metaPath = path.join(s.path, 'resume-index.json');
    let meta: any = null;
    try { meta = JSON.parse(await fs.readFile(metaPath, 'utf8')); } catch {}
    if (!meta) meta = { sessionId: s.sessionId, branches: [], head: null, updatedAt: new Date().toISOString() };
    const exists = meta.branches.find((b:any)=>b.name===opts.name);
    if (exists) {
      console.error(chalk.red(`Branch already exists: ${opts.name}`));
      process.exit(1);
    }
    const branch = {
      branchId: 'b_' + Math.random().toString(36).slice(2,10),
      name: opts.name,
      baseResponseId: opts.from,
      tipResponseId: opts.from,
      createdAt: new Date().toISOString(),
    };
    meta.branches.push(branch);
    meta.head = opts.name;
    meta.updatedAt = new Date().toISOString();
    await fs.writeFile(metaPath, JSON.stringify(meta, null, 2), 'utf8');
    console.log(chalk.green(`Created branch '${opts.name}' at ${opts.from}`));
  });

program.command('checkout')
  .argument('<sessionId>')
  .requiredOption('--branch <branchName>')
  .action(async (sessionId, opts) => {
    const cfg = await loadConfig();
    const dirs = resolveLogDirs(cfg.logDirs);
    const sessions = await indexSessions(dirs);
    const s = sessions.find(x => x.sessionId === sessionId);
    if (!s) {
      console.error(chalk.red(`Session not found: ${sessionId}`));
      process.exit(1);
    }
    const metaPath = path.join(s.path, 'resume-index.json');
    let meta: any = null;
    try { meta = JSON.parse(await fs.readFile(metaPath, 'utf8')); } catch {}
    if (!meta) {
      console.error(chalk.red(`No branches found for session.`));
      process.exit(1);
    }
    const exists = meta.branches.find((b:any)=>b.name===opts.branch);
    if (!exists) {
      console.error(chalk.red(`Branch not found: ${opts.branch}`));
      process.exit(1);
    }
    meta.head = opts.branch;
    meta.updatedAt = new Date().toISOString();
    await fs.writeFile(metaPath, JSON.stringify(meta, null, 2), 'utf8');
    console.log(chalk.green(`Checked out branch '${opts.branch}'.`));
  });

program.command('prune')
  .action(async () => {
    // For now, this is a placeholder. In a real project, we might remove cache files or stale indexes.
    console.log('Nothing to prune yet. Clean by removing per-session resume-index.json files if needed.');
  });

program.parseAsync();
