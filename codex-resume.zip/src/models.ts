export type Role = 'system' | 'user' | 'assistant' | 'tool' | 'developer';

export interface RequestLike {
  model?: string;
  store?: boolean;
  previous_response_id?: string | null;
  instructions?: string | null;
  input?: Array<{ role: Role; content: any } | any> | any;
  created_at?: string | number;
}

export interface ResponseLike {
  id: string;
  created?: number | string;
  output_text?: string | null;
  output_items?: any[] | null;
}

export interface Turn {
  idx: number;
  file: string;
  line: number;
  request?: RequestLike | null;
  response?: ResponseLike | null;
  previous_response_id?: string | null;
  response_id?: string | null;
  created_at?: number;
  summary?: string;
}

export interface SessionSummary {
  sessionId: string;
  path: string;
  files: string[];
  turns: Turn[];
  dagEdges: Array<{ from: string | null; to: string }>;
  tip?: string | null;
  first?: string | null;
  model?: string | null;
}

export interface BranchMeta {
  branchId: string;
  name: string;
  baseResponseId: string;
  tipResponseId: string;
  createdAt: string;
}

export interface SessionIndexFile {
  sessionId: string;
  branches: BranchMeta[];
  head?: string | null; // branch name
  updatedAt: string;
}
