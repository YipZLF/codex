import path from 'node:path';
import { expandHome } from './utils.js';

export function resolveLogDirs(configDirs?: string[]): string[] {
  const defaults = ['~/.codex/sessions', './.codex/sessions'];
  const dirs = (configDirs && configDirs.length ? configDirs : defaults).map(expandHome);
  // de-dup and normalize
  const seen = new Set<string>();
  const out: string[] = [];
  for (const d of dirs) {
    const p = path.resolve(d);
    if (!seen.has(p)) {
      out.push(p);
      seen.add(p);
    }
  }
  return out;
}

export function sessionIndexPath(sessionDir: string) {
  return path.join(sessionDir, 'resume-index.json');
}
