import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';

export function expandHome(p: string): string {
  if (!p) return p;
  if (p.startsWith('~')) {
    return path.join(os.homedir(), p.slice(1));
  }
  return p;
}

export async function ensureDir(p: string) {
  await fs.mkdir(p, { recursive: true });
}

export async function readMaybe(p: string): Promise<string | null> {
  try {
    return await fs.readFile(p, 'utf8');
  } catch {
    return null;
  }
}

export async function writeJSON(p: string, obj: any) {
  await ensureDir(path.dirname(p));
  await fs.writeFile(p, JSON.stringify(obj, null, 2), 'utf8');
}

export async function readJSON<T = any>(p: string): Promise<T | null> {
  try {
    const s = await fs.readFile(p, 'utf8');
    return JSON.parse(s) as T;
  } catch {
    return null;
  }
}

export function safeParseJSON(s: string): any | null {
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}

export function hashText(s: string): string {
  // cheap non-crypto hash
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i);
    h |= 0;
  }
  return (h >>> 0).toString(16);
}

export function toDateNum(x: any): number {
  if (typeof x === 'number') return x;
  if (typeof x === 'string') {
    const t = Date.parse(x);
    if (!Number.isNaN(t)) return t;
    const n = Number(x);
    if (!Number.isNaN(n)) return n;
  }
  return Date.now();
}

export function shortId(id: string | null | undefined, n = 8) {
  if (!id) return '∅';
  return id.length > n ? id.slice(0, n) : id;
}
