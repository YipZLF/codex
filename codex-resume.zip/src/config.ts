import fs from 'node:fs/promises';
import path from 'node:path';
import JSON5 from 'json5';
import { expandHome, readMaybe } from './utils.js';

export interface ResumeConfig {
  logDirs: string[];
  model: string;
  instructionsFile?: string | null;
  mode: 'auto' | 'server' | 'replay';
  store: boolean;
}

const DEFAULTS: ResumeConfig = {
  logDirs: ['~/.codex/sessions', './.codex/sessions'],
  model: 'gpt-4.1',
  instructionsFile: null,
  mode: 'auto',
  store: true,
};

export async function loadConfig(cwd = process.cwd()): Promise<ResumeConfig> {
  const home = expandHome('~/.codex_resume/config.json');
  const local = path.join(cwd, '.codex_resume.json');
  const env = process.env.CODEX_RESUME_CONFIG && expandHome(process.env.CODEX_RESUME_CONFIG);
  const paths = [env, local, home].filter(Boolean) as string[];

  for (const p of paths) {
    try {
      const raw = await fs.readFile(p, 'utf8');
      const obj = JSON5.parse(raw);
      return { ...DEFAULTS, ...obj };
    } catch { /* ignore */ }
  }
  return DEFAULTS;
}

export async function loadInstructions(filePath?: string | null): Promise<string | null> {
  if (!filePath) return null;
  const p = expandHome(filePath);
  const s = await readMaybe(p);
  return s;
}
