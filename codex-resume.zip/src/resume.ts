import OpenAI from 'openai';
import { loadInstructions } from './config.js';
import type { SessionSummary, Turn } from './models.js';

export type ResumeMode = 'auto' | 'server' | 'replay';

export interface ResumeOptions {
  model: string;
  instructionsFile?: string | null;
  store: boolean;
  mode: ResumeMode;
  prompt: string;
}

export interface ResumePlan {
  mode: 'server' | 'replay';
  previous_response_id?: string;
  input: any[];
  instructions: string | null;
  model: string;
  store: boolean;
}

function collectHistoryUpTo(turns: Turn[], targetIdx: number): any[] {
  const msgs: any[] = [];
  for (const t of turns) {
    if (t.idx > targetIdx) break;
    const req = t.request;
    const res = t.response;
    if (req?.input) {
      // Accept both message-style or raw input items
      if (Array.isArray(req.input)) {
        for (const it of req.input) {
          if (typeof it === 'string') msgs.push({ role: 'user', content: it });
          else if (it && typeof it === 'object' && 'role' in it) msgs.push(it);
          else msgs.push({ role: 'user', content: JSON.stringify(it) });
        }
      } else {
        msgs.push({ role: 'user', content: typeof req.input === 'string' ? req.input : JSON.stringify(req.input) });
      }
    }
    if (res) {
      // Try to reconstruct assistant message
      if (res.output_text) {
        msgs.push({ role: 'assistant', content: res.output_text });
      } else if (res.output_items && Array.isArray(res.output_items)) {
        // Best-effort: flatten to text
        const text = res.output_items.map((x:any) => {
          const c = x?.content?.[0]?.text ?? x?.text ?? JSON.stringify(x);
          return typeof c === 'string' ? c : JSON.stringify(c);
        }).join('\n');
        msgs.push({ role: 'assistant', content: text });
      }
    }
  }
  return msgs;
}

export async function makeResumePlan(session: SessionSummary, atResponseId: string | null, atStep: number | null, opts: ResumeOptions): Promise<ResumePlan> {
  const instructions = await loadInstructions(opts.instructionsFile ?? null);

  // choose target turn
  let target: Turn | undefined;
  if (atResponseId) {
    target = session.turns.find(t => t.response_id === atResponseId);
  } else if (typeof atStep === 'number') {
    target = session.turns.find(t => t.idx === atStep);
  } else {
    // default: last turn with response_id
    for (let i = session.turns.length - 1; i >= 0; i--) {
      const t = session.turns[i];
      if (t.response_id) { target = t; break; }
    }
  }
  if (!target) {
    throw new Error('Cannot locate target turn. Provide --at <responseId> or --step <n>.');
  }

  const canServerChain = Boolean(target.response_id);
  let mode: 'server' | 'replay' = 'replay';
  if (opts.mode === 'server') mode = 'server';
  else if (opts.mode === 'replay') mode = 'replay';
  else mode = canServerChain ? 'server' : 'replay';

  if (mode === 'server') {
    return {
      mode,
      previous_response_id: target.response_id!,
      input: [{ role: 'user', content: opts.prompt }],
      instructions: instructions ?? null,
      model: opts.model,
      store: opts.store,
    };
  } else {
    const history = collectHistoryUpTo(session.turns, target.idx);
    return {
      mode,
      input: [...history, { role: 'user', content: opts.prompt }],
      instructions: instructions ?? null,
      model: opts.model,
      store: opts.store,
    };
  }
}

export async function executePlan(plan: ResumePlan, client: OpenAI): Promise<string> {
  const resp = await client.responses.create({
    model: plan.model,
    store: plan.store,
    ...(plan.previous_response_id ? { previous_response_id: plan.previous_response_id } : {}),
    ...(plan.instructions ? { instructions: plan.instructions } : {}),
    input: plan.input,
  } as any);

  // Extract assistant text best-effort
  // @ts-ignore
  const out = resp.output_text ?? (resp.output && Array.isArray(resp.output) ? resp.output.map((x:any)=>x?.content?.[0]?.text ?? '').join('\n') : '');
  return typeof out === 'string' && out.trim() ? out : JSON.stringify(resp, null, 2);
}
