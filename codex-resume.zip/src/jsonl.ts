import fs from 'node:fs';
import readline from 'node:readline';
import { safeParseJSON } from './utils.js';

export async function* readJsonl(file: string): AsyncGenerator<{ line: number; obj: any }> {
  const stream = fs.createReadStream(file, { encoding: 'utf8' });
  const rl = readline.createInterface({ input: stream, crlfDelay: Infinity });
  let i = 0;
  for await (const line of rl) {
    i++;
    const obj = safeParseJSON(line);
    if (obj) yield { line: i, obj };
  }
}
