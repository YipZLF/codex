import path from 'node:path';
import fg from 'fast-glob';
import { readJsonl } from './jsonl.js';
import { toDateNum } from './utils.js';
import type { SessionSummary, Turn, ResponseLike, RequestLike } from './models.js';

const FILE_GLOBS = [
  '**/rollout-*.jsonl',
  '**/*session*.jsonl',
  '**/*conversation*.jsonl',
  '**/*.jsonl',
];

function extractResponse(obj: any): ResponseLike | null {
  // Heuristics for various response payload shapes
  if (!obj || typeof obj !== 'object') return null;
  if (obj.response && typeof obj.response === 'object' && typeof obj.response.id === 'string') {
    const r = obj.response;
    const outputText = (r.output_text ?? r.output?.[0]?.content?.[0]?.text ?? null) as string | null;
    return { id: r.id, created: r.created, output_text: outputText, output_items: r.output ?? null };
  }
  if (typeof obj.id === 'string' && (obj.type === 'response' || obj.object === 'response')) {
    const outputText = (obj.output_text ?? obj.output?.[0]?.content?.[0]?.text ?? null) as string | null;
    return { id: obj.id, created: obj.created, output_text: outputText, output_items: obj.output ?? null };
  }
  return null;
}

function extractRequest(obj: any): RequestLike | null {
  if (!obj || typeof obj !== 'object') return null;
  // Common embedding inside event-like records
  const r = obj.request ?? obj.req ?? obj.body ?? obj;
  if (typeof r !== 'object') return null;
  const hasInput = 'input' in r || 'messages' in r;
  const hasPrev = 'previous_response_id' in r;
  const looksLike = hasInput || hasPrev || 'model' in r || 'instructions' in r;
  if (!looksLike) return null;
  const input = r.input ?? r.messages ?? null;
  return {
    model: r.model,
    store: r.store,
    previous_response_id: r.previous_response_id ?? null,
    instructions: r.instructions ?? null,
    input,
    created_at: obj.created_at ?? obj.timestamp ?? obj.time ?? Date.now(),
  };
}

export async function indexSessions(dirs: string[]): Promise<SessionSummary[]> {
  const sessions: SessionSummary[] = [];
  for (const dir of dirs) {
    const files = await fg(FILE_GLOBS, { cwd: dir, dot: true, absolute: true });
    // group by parent dir as session
    const byDir = new Map<string, string[]>();
    for (const f of files) {
      const parent = path.dirname(f);
      const arr = byDir.get(parent) ?? [];
      arr.push(f);
      byDir.set(parent, arr);
    }
    for (const [sessionDir, jsonlFiles] of byDir.entries()) {
      const turns: Turn[] = [];
      let idx = 0;
      for (const file of jsonlFiles.sort()) {
        for await (const { line, obj } of readJsonl(file)) {
          const req = extractRequest(obj);
          const res = extractResponse(obj);
          if (!req && !res) continue;
          const t: Turn = {
            idx: idx++,
            file,
            line,
            request: req,
            response: res,
            previous_response_id: req?.previous_response_id ?? null,
            response_id: res?.id ?? null,
            created_at: toDateNum(res?.created ?? req?.created_at ?? Date.now()),
            summary: (res?.output_text && String(res.output_text).slice(0, 80)) || null || undefined,
          };
          turns.push(t);
        }
      }
      if (!turns.length) continue;
      const nodes = new Set<string>();
      const edges: Array<{ from: string | null; to: string }> = [];
      let first: string | null = null;
      let tip: string | null = null;
      for (const t of turns) {
        if (t.response_id) {
          nodes.add(t.response_id);
          if (!first) first = t.response_id;
          tip = t.response_id;
          const prev = t.previous_response_id ?? null;
          if (prev) {
            edges.push({ from: prev, to: t.response_id });
          } else {
            edges.push({ from: null, to: t.response_id });
          }
        }
      }
      const sessionId = path.basename(sessionDir);
      sessions.push({
        sessionId,
        path: sessionDir,
        files: jsonlFiles,
        turns,
        dagEdges: edges,
        tip,
        first,
        model: turns.find(t => t.request?.model)?.request?.model ?? null,
      });
    }
  }
  // stable order by mtime of latest file or by name
  sessions.sort((a, b) => a.sessionId.localeCompare(b.sessionId));
  return sessions;
}
