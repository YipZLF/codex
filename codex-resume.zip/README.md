# codex-resume

Resume / rollback / branch manager for **Codex CLI** sessions.

It supports two recovery paths:

- **Server chain** — if earlier requests were made with `store: true`, you can resume with
  `previous_response_id` (no need to resend the whole history).
- **Local replay** — rebuild the `input` up to any historical turn from your local JSONL
  logs and send a fresh request.

> ⚠️ KV cache is *not* loadable by clients. This tool never tries to "load KV".
> It either continues the server-side chain or replays locally.

## Install

```bash
npm i -g codex-resume
# or, from source:
npm i
npm run build
npm link
```

## Prepare config

Create `~/.codex_resume/config.json` (or a project-local `.codex_resume.json`).

```json5
{
  // Where your Codex CLI saves sessions:
  "logDirs": ["~/.codex/sessions", "./.codex/sessions"],
  // Default model and instructions when resuming
  "model": "gpt-4.1",
  "instructionsFile": "~/.codex_resume/instructions.md",
  // auto | server | replay
  "mode": "auto",
  // default store flag when creating new responses
  "store": true
}
```

Put your usual assistant rules in `instructions.md`.

Export your API key:

```bash
export OPENAI_API_KEY=sk-...  # required for resume calls
```

## CLI

```bash
codex-sessions list [--json]
codex-sessions show <sessionId>
codex-sessions resume <sessionId>   [--at <responseId> | --step <n> | --first]   [--prompt "<your next user message>" | --prompt-file path]   [--mode auto|server|replay] [--model <model>]   [--instructions-file path] [--store] [--no-store]   [--dry-run]
codex-sessions branch <sessionId> --from <responseId> --name <branchName>
codex-sessions checkout <sessionId> --branch <branchName>
codex-sessions prune
```

### What counts as a "session"?

Any directory under `logDirs` containing JSONL files like `rollout-*.jsonl` (the default for Codex CLI).
The tool scans those files and tries to infer `response.id` and `previous_response_id` edges.

### How "resume" chooses the path

- `--mode server`: use `previous_response_id` and send only the new input.
- `--mode replay`: rebuild the full `input` up to the chosen turn and send fresh.
- `--mode auto` (default): if the target turn has a `response.id`, prefer `server`;
  otherwise, fall back to `replay`.

### Limitations

- JSONL structures may vary across Codex CLI versions. The parser uses heuristics:
  it looks for `response.id`, `previous_response_id`, `.request.input`, and common
  response content fields. If your logs differ, tune `src/indexer.ts` accordingly.
- Tool/file uploads from earlier turns must be re-provided for the replay path.
- `instructions` are not implicitly carried by `previous_response_id`; they are re-sent each call.

## Dev

```bash
npm run build
node dist/index.js list
```

MIT licensed.
